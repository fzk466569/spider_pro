#!/usr/bin/python
# -*- coding: utf-8 -*-
# @Time    : 2017/4/25 15:57

import top.api
import sys

reload(sys)
sys.setdefaultencoding('utf8')

appkey = '23604482'
secret = ''
sign = '樊志魁'
msgTemplate = "SMS_63035361"    # 12306余票查询
errorTemplate = 'SMS_63415071'  # 错误信息模板


def send_msg(json, tel='17600617116'):
    req = top.api.AlibabaAliqinFcSmsNumSendRequest()
    req.set_app_info(top.appinfo(appkey, secret))
    req.extend = ""
    req.sms_type = "normal"
    req.sms_free_sign_name = sign
    req.sms_param = json
    req.rec_num = tel
    req.sms_template_code = msgTemplate
    try:
        resp = req.getResponse()
        print (resp)
    except Exception, e:
        print (e)


def send_error_msg(json, tel='17600617116'):
    req = top.api.AlibabaAliqinFcSmsNumSendRequest()
    req.set_app_info(top.appinfo(appkey, secret))
    req.extend = ""
    req.sms_type = "normal"
    req.sms_free_sign_name = sign
    req.sms_param = json
    req.rec_num = tel
    req.sms_template_code = errorTemplate
    try:
        resp = req.getResponse()
        print (resp)
    except Exception, e:
        print (e)
