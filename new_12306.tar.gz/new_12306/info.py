#!/usr/bin/python
# -*- coding: utf-8 -*-
# @Time    : 2017/4/25 13:40

from config import get_station_val

# 接受短信人的姓名
# 接受短信人的手机号
name, phone = u'樊志魁', '17600617116'
date = '2017-04-28'
from_ = '北京'
to_ = '忻州'
# 默认空为所有车次 大小写敏感 可写入多个值 exp：['K601', 'K602']
custom_train_no = ['K601']

from_station = get_station_val(from_)
to_station = get_station_val(to_)
