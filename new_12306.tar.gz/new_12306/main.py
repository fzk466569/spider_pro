#!/usr/bin/python
# -*- coding: utf-8 -*-
# @Time    : 2017/4/26 08:48

import requests
import json
import warnings
import time
import random

from config import load_ua
from info import date, from_, to_, name, phone, from_station, to_station, custom_train_no
from send_msg import send_msg

warnings.filterwarnings("ignore")


class LeftTickets(object):
    def __init__(self):
        self.date = date
        self.dict = {}
        self.train_no = custom_train_no
        self.from_station = from_station
        self.to_station = to_station
        self.FLAG = True
        self.headers = {
            'User-Agent': load_ua(),
        }
        self.url = "https://kyfw.12306.cn/otn/leftTicket/query?leftTicketDTO.train_date=%s&leftTicketDTO." \
                   "from_station=%s&leftTicketDTO.to_station=%s&purpose_codes=ADULT" % (date, from_station, to_station)

    def get_data(self):
        res = requests.get(self.url, verify=False, headers=self.headers)
        data_dict = json.loads(res.text)
        return data_dict.get('data').get('result')

    def parse_data(self, left_data):
        for x in left_data:
            base_dict = {}
            data = x.split('|')
            base_dict['train_code'] = data[3]
            base_dict['yz_num'] = data[29]
            base_dict['start_time'] = data[8]
            base_dict['arrive_time'] = data[9]
            base_dict['time'] = data[10]
            if self.train_no and base_dict.get('train_code') in self.train_no:
                self.get_yz_num(base_dict)

    def get_yz_num(self, base_dict):
        if base_dict.get('yz_num') != u'无' and base_dict.get('yz_num') != '--':
            result_dict = {}
            result_dict['train_no'] = base_dict.get('train_code')
            result_dict['start'] = base_dict.get('start_time')
            # 到达时间，路上时间，硬座数量
            # result_dict['arrive_time'] = base_dict.get('arrive_time')
            # result_dict['time'] = base_dict.get('time')
            # result_dict['yz_num'] = base_dict.get('yz_num')
            result_dict['from'] = from_
            result_dict['to'] = to_ + ' ' + date
            result_dict['name'] = name
            self.dict = result_dict
            self.FLAG = False

if __name__ == '__main__':
    # 循环抢票
    num = 0
    lt = LeftTickets()
    while lt.FLAG:
        try:
            num += 1
            seconds = random.randint(1, 5)
            print 'seconds', seconds
            time.sleep(seconds)
            lt.parse_data(lt.get_data())
            if not lt.FLAG:
                # print 'send_msg'
                # print json.dumps(lt.dict, indent=4)
                send_msg(json.dumps(lt.dict), phone)
            print num
        except Exception:
            pass
